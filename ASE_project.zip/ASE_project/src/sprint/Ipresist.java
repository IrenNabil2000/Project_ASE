package sprint;

public interface Ipresist {

}
