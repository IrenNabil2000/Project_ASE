package sprint;

public interface iNotification {

}
