package sprint;

public interface iTemplate {
	
	
}
