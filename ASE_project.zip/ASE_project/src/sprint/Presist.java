package sprint;

import java.util.ArrayList;

public class Presist implements Ipresist{
	ArrayList<Template> list = new ArrayList<Template>( );
	Presist(){
		Notification n1=new Notification();
		n1.t.setSub("email confirmation");
		n1.t.setAvll("english");
		n1.t.setAvlc("email");
		n1.t.setCont(n1);
		list.add(n1.t);
		Notification n2=new Notification();
		n2.t.setSub("forget password");
		n2.t.setAvll("english");
		n2.t.setAvlc("email");
		n2.t.setCont(n2);
		list.add(n2.t);
	}
	public Notification create(String subj,String lanaguge,String channel) {
		Notification n=new Notification();
		n.t.setSub(subj);
		n.t.setAvll(lanaguge);
		n.t.setAvlc(channel);
		n.t.setCont(n);
		list.add(n.t);
		return n;
		
	}
}
