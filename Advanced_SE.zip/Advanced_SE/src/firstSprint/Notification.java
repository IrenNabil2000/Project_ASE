package firstSprint;

public class Notification {
	Template t=new Template();

}
