package com.example.Notification;

import com.example.Notification.model.NotificationTemplate;

public class Buy extends NotificationTemplate {
	public String item="Mobile charger";
	public void setItem(String item)
	{
		this.item=item;
	}
	public Buy()
	{
		setSubject("Buy Conformation");
		setContent("Dear, "+to+" Your booking of the "+item+" is confirmed. Thanks for using our store :)");
		
	}

}
