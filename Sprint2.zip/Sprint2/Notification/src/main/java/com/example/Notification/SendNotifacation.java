package com.example.Notification;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

import com.example.Notification.model.NotificationTemplate;


public class SendNotifacation {
	  private Queue<NotificationTemplate> smsQueue=new LinkedList<>();
	    private Queue<NotificationTemplate> mailQueue=new LinkedList<>();
	
	public Queue<NotificationTemplate> send(NotificationTemplate t)
	{
		if(t.getChannel().equalsIgnoreCase("email"))
		{
			mailQueue.add(t);
			return mailQueue;
		}
		else
		{
			smsQueue.add(t);
			return smsQueue;
		}
		
		
	}
	/*
	public Queue<NotificationTemplate> read (Queue<NotificationTemplate>t) {

        Iterator<NotificationTemplate> iterator = t.iterator();
        if(iterator.next().getChannel().equalsIgnoreCase("sms"))
        	return smsQueue;
        else
        	return mailQueue;   
}*/
	public void display(Queue<NotificationTemplate>t) {

        Iterator<NotificationTemplate> iterator = t.iterator(); 
    
          while (iterator.hasNext()) { 
              iterator.next().display(); 
          } 

      
}
    

}
