package com.example.Notification.repository;

import java.util.ArrayList;

import com.example.Notification.model.*;
import org.springframework.stereotype.Repository;



@Repository("notifyRepo")
public class MemoryNotificationTemplateDataAccessLayer implements INotificationTemplateDataAccessLayer {
	
    private ArrayList<NotificationTemplate> AllTemplates= new ArrayList<NotificationTemplate>();
    
   public MemoryNotificationTemplateDataAccessLayer()
    {
        NotificationTemplate t=new NotificationTemplate();
        t.setSubject("email confirmation");
        t.SetLanguage(LanguageEnum.valueOf("English"));
        t.setContent("Your email is confirmed");
        t.setChannel("mail");
        t.setId(1);
        AllTemplates.add(t);
    }
    public boolean subjectValidations(String subject)
    {
        for(int i=0;i<AllTemplates.size();i++)
        {
            if(subject.equalsIgnoreCase(AllTemplates.get(i).getSubject()))
                return false;
        }
        return true;
    }
    public boolean languageValidations(LanguageEnum languageInput) {
        String lan=languageInput.toString();
        if(lan.equalsIgnoreCase("English" )|| lan.equalsIgnoreCase("Arabic")) {
            return true;
        }
        else
            return false;
    }
    
	@Override
     public boolean AddTemplate( NotificationTemplate template) {
         boolean flag = true;
         boolean flag2 = true;
         if (subjectValidations(template.getSubject()) == false) {
             System.out.println("ERROR THIS TEMPLATE ALREADY EXISTS");
         } else {
             if (languageValidations(template.getLanguage())) {

                 flag = true;
             } else {
                 System.out.println("Please choose English or Arabic only");
                 flag = false;
             }
             if (flag == true && flag2 == true) {
                 AllTemplates.add(template);
                 return true;
             }
         }
         return false;
     }
	
	@Override
    public  boolean DeleteTemplate(Integer templateId)
    {
        for(int i=0;i<AllTemplates.size();i++)
        {
            if(templateId==AllTemplates.get(i).getId()) {
                AllTemplates.remove(AllTemplates.get(i));
                return true;
            }
        }
        return  false;
    }
    public boolean UpdateTemplate(NotificationTemplate template)
    {
        for(int i=0;i<AllTemplates.size();i++)
        {
            if(template.getId()==AllTemplates.get(i).getId())
            {
                AllTemplates.get(i).setSubject(template.getSubject());
                AllTemplates.get(i).setContent(template.getContent());
                AllTemplates.get(i).SetLanguage(template.getLanguage());
                AllTemplates.get(i).setChannel(template.getChannel());
                return true;
            }
        }
        return  false;
    }
    
	@Override
    public NotificationTemplate GetTemplate(Integer templateId)
    {
        for(int i=0;i<AllTemplates.size();i++)
        {
            if(templateId==AllTemplates.get(i).getId())
            {
                return (AllTemplates.get(i));
            }
        }
        return null;
    }
	
	@Override
    public  ArrayList<NotificationTemplate> SearchTemplates(SearchCriteria criteria)
    {
        ArrayList<NotificationTemplate> listt = new ArrayList<NotificationTemplate>();
        for(int i=0;i<AllTemplates.size();i++)
        {
            if ((criteria.getContent().equals(AllTemplates.get(i).getContent())) ||
                (criteria.getSubject().equals(AllTemplates.get(i).getSubject())) ||
                (criteria.getLanguage().equals(AllTemplates.get(i).getLanguage())) ||
                (criteria.getChannel().equals(AllTemplates.get(i).getChannel())))
            {
                listt.add(AllTemplates.get(i));
            }
        }
        return  listt;
    }

	
    public  ArrayList<NotificationTemplate> GetAllTemplates() {

		return AllTemplates;
       // for (int i = 0; i < AllTemplates.size(); i++)
            //System.out.println("Subject:" + AllTemplates.get(i).spec.getSubject() + "\n" + "content:" + AllTemplates.get(i).spec.getContent() + "\n" + "Lang:" + AllTemplates.get(i).spec.getLanguage()+"\n");

    }
    public void displayTemplate(ArrayList<NotificationTemplate>t) {

        for (int i = 0; i < t.size(); i++)
            System.out.println("Subject:" + t.get(i).getSubject() +
                    "\n" + "content:" + t.get(i).getContent() + "\n" +
                    "Lang:" + t.get(i).getLanguage()+"\n "+"Channel: "+t.get(i).getChannel());

    }
   @Override
    public void displayTemplate(NotificationTemplate t) {
    	System.out.println("Subject:" + t.getSubject() +
                    "\n" + "content:" + t.getContent() + "\n" +
                    "Lang:" + t.getLanguage()+"\n "+"Channel: "+t.getChannel());

    }

}
