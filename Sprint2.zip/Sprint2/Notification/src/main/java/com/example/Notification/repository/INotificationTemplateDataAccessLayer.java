package com.example.Notification.repository;

import java.util.ArrayList;

import com.example.Notification.model.*;


public interface INotificationTemplateDataAccessLayer {
	
    public boolean subjectValidations(String subject);
    public boolean languageValidations(LanguageEnum languageInput);
    public boolean AddTemplate( NotificationTemplate template);
    public  boolean DeleteTemplate(Integer templateId);
    public boolean UpdateTemplate(NotificationTemplate template);
    public NotificationTemplate GetTemplate(Integer templateId);
    public ArrayList<NotificationTemplate> SearchTemplates(SearchCriteria criteria);
    public  ArrayList<NotificationTemplate> GetAllTemplates();
    public void displayTemplate(ArrayList<NotificationTemplate>t);
	public void displayTemplate(NotificationTemplate t);

}
