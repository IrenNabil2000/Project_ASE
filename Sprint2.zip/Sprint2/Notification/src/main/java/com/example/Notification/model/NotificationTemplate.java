package com.example.Notification.model;

import com.fasterxml.jackson.annotation.JsonProperty;

	public class NotificationTemplate {
	
		protected String Subject="";
		protected String Content="";
		protected LanguageEnum Language=LanguageEnum.Arabic;
		protected String channel="mail";
		 protected  int id=0;
			protected  String to="Hassan";

			    public NotificationTemplate(@JsonProperty("id") int id, String to,
			    		@JsonProperty("subject") String Subject, @JsonProperty("content")String Content,
						@JsonProperty("language") LanguageEnum Language, @JsonProperty("channel")String channel){
			        this.id=id;
			        this.to=to;
			        this.Subject=Subject;
			        this.Content=Content;
			        this.Language=Language;
			        this.channel=channel;
			    }
			public void setTo(String to)
			{
				this.to=to;
			}
			protected String getTo()
			{
				return to;
			}
		 public int getId() {
			 return id;
		 }

			public void setId(int id) {
				this.id = id;
			}
			public void setChannel(String channel)
			{
				this.channel=channel;
			}
			public String getChannel()
			{
				return channel;
			}
			public void setSubject(String newSub) {
			    this.Subject= newSub;
			  }
			public void setContent(String newcont) {
			    this.Content= newcont;
			  }
			public void SetLanguage(LanguageEnum l) {
				 this.Language= l;
				
			}

			public String getSubject() {
			    return Subject;
			  }
		    public String getContent() {
				    return Content;
				  }
				  
		   public LanguageEnum getLanguage() {
					 
			 return  Language;
					  }

			//public SearchCriteria spec=new SearchCriteria();
		public NotificationTemplate(){
		}


		public void display() {
			System.out.println("subject: "+getSubject()+"\n content:"+getContent()+"\n language:"+
		getLanguage()+"\n Channel: "+getChannel());
			
		}



}
