package com.example.Notification;

import com.example.Notification.model.NotificationTemplate;

public class Forget extends NotificationTemplate{
	
	Forget() {
		setSubject("Forget Password");
		setContent("Dear, "+to+" You can reset your password") ;		
		}

}
