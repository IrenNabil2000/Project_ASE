package com.example.Notification;

import com.example.Notification.model.NotificationTemplate;

public class Email extends NotificationTemplate {
	
	public Email()
	{
		setSubject("Email Conformation");
		setContent("Dear, "+getTo()+" Your email is confirmed.");
		
	}

}
