package com.example.Notification;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

import com.example.Notification.model.LanguageEnum;
import com.example.Notification.model.NotificationTemplate;
import com.example.Notification.repository.MemoryNotificationTemplateDataAccessLayer;



public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MemoryNotificationTemplateDataAccessLayer repo=new MemoryNotificationTemplateDataAccessLayer();
        ArrayList<MemoryNotificationTemplateDataAccessLayer> m=new 	ArrayList<MemoryNotificationTemplateDataAccessLayer>();
        repo.GetTemplate(1).display();
        NotificationTemplate t=new Buy();        
        t.setId(2);
        if(repo.AddTemplate(t))
        {
        	
            repo.GetTemplate(2).display();
        }
        else
            System.out.println("not added");
        t.setSubject("Conformation ");
        if(repo.UpdateTemplate(t))
        {
            repo.GetTemplate(2).display();
        }
        else
            System.out.println("not updated");
        if(repo.DeleteTemplate(t.getId()))
        {
            repo.displayTemplate(t);
            System.out.println("deleted");
        }
        else
            System.out.println("not deleted ");
        
        t.SetLanguage(LanguageEnum.valueOf("English"));
        //repo.read(repo.SearchTemplates(t));
        System.out.println("============================ ");
        //invoked to be sent
        SendNotifacation send=new SendNotifacation();
        
        send.display( send.send(t));

    }


	}


